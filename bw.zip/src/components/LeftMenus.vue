<template>
  <div class="navMenu">
    <label v-for="(v,i) in navMenus" :key="i">
      <!--只有一级菜单-->
      <el-menu-item
        v-if="!v.children"
        :index="v.path"
        :route="v.path"
      >
        <!--图标-->
        <i :class="v.icon"></i>
        <!--标题-->
        <span slot="title">{{ v.title }}</span>
      </el-menu-item>
      <!--有多级菜单-->
      <el-submenu
        v-if="v.children"
        :key="v.path"
        :index="v.path"
      >
        <template slot="title">
          <i :class="v.icon"></i>
          <span> {{ v.title }}</span>
        </template>
        <!--递归组件，把遍历的值传回子组件，完成递归调用-->
        <navMenu :navMenus="v.children"></navMenu>
      </el-submenu>
    </label>
  </div>
</template>

<script>
export default {
  name: "NavMenu", //使用递归组件必须要有
  props: ["navMenus"], // 传入子组件的数据
  data() {
    return {};
  },
  methods: {},
  created(){
    console.log(this.navMenus)
  }
};
</script>

<style scoped>
</style>