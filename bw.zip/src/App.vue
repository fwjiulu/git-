<template>
  <div id="app">
    <!-- <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </div> -->
    <router-view/>
  </div>
</template>

<style lang="less">
.wh(@w:100%,@h:100%){width: @w;height: @h;}
#app,html,body{.wh;}
*{margin: 0;padding: 0;box-sizing: border-box;}
img{.wh;display: block;}



</style>
