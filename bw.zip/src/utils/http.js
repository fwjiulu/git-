import axios from 'axios'
import qs from 'qs'
const http = axios.create({
    baseURL:"http://bw.gsruiying.com.cn/",
    timeout: 10000,
});
http.interceptors.request.use(function (config) {
    if (config.data && !(config.data instanceof FormData)) {
        config.data = qs.stringify(config.data)
    }
    config.params={
        ...config.params,
        // token:""
    }
    config.headers["Authori-zation"]="Bearer "+sessionStorage.getItem("auth_token")
    return config;
}, function (error) {
    return Promise.reject(error);
});
http.interceptors.response.use(function (response) {
    return response.status === 200 ? response.data : response;
}, function (error) {
    return Promise.reject(error);
});
export const post = (url, data) => {
    return new Promise((resolve, reject) => {
        http.post(url, data).then(res => {
            resolve(res)
        }).catch(err => {
            reject(err)
        })
    })
}
export const get = (url, data) => {
    return new Promise((resolve, reject) => {
        http.get(url, { params: data }).then(res => {
            resolve(res)
        }).catch(err => {
            reject(err)
        })
    })
}
export default http