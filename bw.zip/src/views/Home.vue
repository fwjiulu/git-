<template>
  <div class="home_box">
    <!-- 最外层的大盒子 -->
    <el-container>
      <!-- 最左边的盒子 -->
      <el-aside width="15%">
        <!-- 左侧菜单的盒子 -->
        <el-menu
          default-active="2"
          class="el-menu-vertical-demo"
          @select="handleSelect"
          @open="handleOpen"
          @close="handleClose"
          background-color="#545c64"
          text-color="#fff"
          active-text-color="#ffd04b"
        >
        <Left-menus :navMenus="left_list"/>
          <!-- <div v-for="(v, i) in left_list" :key="i">
            <el-menu-item v-if="!v.children" :index="i">
              <span slot="title">
                <router-link :to="v.path">{{ v.title }}</router-link></span
              >
            </el-menu-item>
            <el-submenu v-else :index="i">
              <template slot="title">
                <span>{{ v.title }}</span>
              </template>
              <el-menu-item-group
                v-for="(x, y) in v.children"
                :key="y"
                :index="i + '-' + y"
              >
                <el-menu-item v-if="!x.children" :index="i + '-' + y">
                  <router-link :to="x.path">{{ x.title }}</router-link>
                </el-menu-item>
                <el-submenu v-else :index="i + '-' + y">
                  <template slot="title">{{ x.title }}</template>
                  <el-menu-item
                    v-for="(a, b) in x.children"
                    :key="b"
                    :index="i + '-' + y + '-' + b"
                    ><router-link :to="a.path">{{
                      a.title
                    }}</router-link></el-menu-item
                  >
                </el-submenu>
              </el-menu-item-group>
            </el-submenu>
          </div> -->
        </el-menu></el-aside
      >
      <!-- 右边的数据的盒子 -->
      <el-main>home_box<router-view /></el-main>
    </el-container>
    <!-- <img alt="Vue logo" src="../assets/logo.png">
    <HelloWorld msg="Welcome to Your Vue.js App"/> -->
  </div>
</template>

<script>
import LeftMenus from "@/components/LeftMenus.vue";
export default {
  data() {
    return { left_list: [] };
  },
  methods: {
    handleSelect(key, keyPath) {
      console.log(key, keyPath);
    },
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath);
    },
  },
  components: {
    LeftMenus,
  },
  created() {
    this.left_list = JSON.parse(sessionStorage.getItem("left_list"));
    console.log(this.left_list);
  },
};
</script>
<style lang="less" scoped>
.wh(@w:100%,@h:100%) {
  width: @w;
  height: @h;
}
.home_box,
.el-container {
  .wh;
  a{color: white;}
  .el-aside,
  .el-menu {
    height: 100%;
  }
}
</style>