<template>
  <div class="Login_box">
    <canvas id="c_n4" width="847" height="722" class="index_bg" style="position: fixed; top: 0px; left: 0px; z-index: -2; opacity: 0.8;"></canvas>
    <div class="xbox">
      <div class="leftbox">
        <img
          src="http://bw.gsruiying.com.cn/admin/view_admin/img/sw.e11bce53.jpg"
          alt=""
        />
      </div>
      <div class="rightbox">
        <div class="logobox">
          <img
            src="http://bw.gsruiying.com.cn/admin/view_admin/img/logo.4d95a494.png"
            alt=""
          />
        </div>
        <el-form
          :model="ruleForm"
          status-icon
          :rules="rules"
          ref="ruleForm"
          label-width="20px"
          class="demo-ruleForm"
        >
          <el-form-item prop="username">
            <el-input
              placeholder="请输入用户名"
              type="text"
              v-model="ruleForm.username"
              autocomplete="off"
            ></el-input>
          </el-form-item>
          <el-form-item prop="pass">
            <el-input
              placeholder="请输入密码"
              type="password"
              v-model="ruleForm.pass"
              autocomplete="off"
            ></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm')"
              >提交</el-button
            >
            <el-button @click="resetForm('ruleForm')">重置</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>
</template>
<script>
import { login_api } from "@/api/api";
export default {
  data() {
    var validatePass = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入密码"));
      } else if (!/^\w{6,}$/.test(value)) {
        callback(new Error("密码格式有误"));
      } else {
        callback();
      }
    };
    var validateUserName = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入用户名"));
      } else if (!/^\w{5,}$/.test(value)) {
        callback(new Error("用户名格式有误"));
      } else {
        callback();
      }
    };
    return {
      ruleForm: {
        pass: "",
        username: "",
      },
      rules: {
        pass: [{ validator: validatePass, trigger: "blur" }],
        username: [{ validator: validateUserName, trigger: "blur" }],
      },
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          login_api({
            account: this.ruleForm.username,
            pwd: this.ruleForm.pass,
          }).then((res) => {
            console.log(res);
            if (res.status === 200) {
              this.$message.success("登录成功");
              sessionStorage.setItem("auth_token", res.data.token);
              sessionStorage.setItem("left_list", JSON.stringify(res.data.menus));
            } else {
              this.$message.error("登录失败 " + res.msg);
            }
          });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
  },
  components: {},
  created() {},
};
</script>
<style lang="less" scoped>
.wh(@w:100%,@h:100%) {
  width: @w;
  height: @h;
}
.Login_box {
  .index_bg {
    width: 100%;
    background: rgba(0,0,0,.6)!important;
    z-index: 0!important;
}
  .wh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: url("http://bw.gsruiying.com.cn/admin/view_admin/img/bg.7e15c493.jpg")
    no-repeat;
  background-size: 100% 100%;
  .xbox {
    z-index: 1;
    .wh(900px,450px);
    background: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
    .leftbox {
      .wh(60%);
    }
    .rightbox {
      .wh(40%);
      display: flex;
      flex-direction: column;
      justify-content: space-around;
      .logobox{.wh(100%,20%)}
    }
  }
}
</style>