import { post, get } from "@/utils/http"
import http from '@/utils/http'
//登录接口
export const login_api = (data) => {
    return post("/adminapi/login", data)
    /* account         账号，      默认是admin            （字符串）
 pwd              密码          默认是admin123      （字符串）
  imgcode        验证码           （字符串） */
}
//商品信息列表
export const product_api = (data) => {
    return get("adminapi/product/product", data)
    /**   page	mediumint(11)	1	页数
*   limit	varchar(100)		每页请求的条数
*   cate_id	mediumint(11)		选中商品分类的id
*   type	varchar(128)	1	1：出售中的商品2：仓库中的商品4：已经  售馨商品5：警戒库存商品6：回收站的商品
*   store_name	tinyint(1)		搜索的商品名称
*excel	int(11)	0	
sales	int(11)   unsigned		销量：asc由低到高，desc由高到低
 */
}
//商品信息列表上/下架切换
export const set_show_api = (data) => {
    return http.put("adminapi/product/product/set_show/:id/:is_show", data)
    //Params: id代表当前修改的数据id is_show :  0:下架  1:上架
}
//商品顶部信息
export const header_api = () => {
    return get("adminapi/product/product/type_header")
}
//商品渲染
export const product_rule_api = (data,) => {
    return get("adminapi/product/product/rule",data)
    /*page: 1
    limit: 15 */
}





